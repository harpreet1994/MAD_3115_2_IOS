//
//  TableItems.swift
//  EatIn
//
//  Created by MacStudent on 2018-08-11.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class TableItems{
    static var titles : [String] = ["Breakfast", "Lunch","Dinner", "Web View", "Calender","Contacts"]
    static var subTitles : [String] = ["Breakfast like A king", "Lunch like a Queen", "Dine Like a pouper" ,"World is yours", "Time is not yours",  "Stay Connected"]
    
    static var images : [String] = ["Breakfast", "Lunch","Dinner", "Web", "Calender","Contacts"]
}
