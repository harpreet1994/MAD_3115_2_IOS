//
//  RegisterVC.swift
//  PatakaPatandar
//
//  Created by MacStudent on 2018-08-04.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class RegisterVC: UIViewController {
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblDOB: UILabel!
    
    @IBOutlet weak var lblUserName: UILabel!
    
    @IBOutlet weak var lblGender: UILabel!
    
    
    @IBOutlet weak var txtName: UITextField!
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtAddress: UITextField!
    
   
    @IBOutlet weak var datePckrDOB: UIDatePicker!
    
    @IBOutlet var txtUserName: [UITextField]!
    
    @IBOutlet weak var sgmntGender: UISegmentedControl!
    
    
    @IBOutlet weak var btnRegister: UIButton!
    
    
    @IBOutlet weak var btnCancel: UIButton!
    
   
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func btnRegisterAction(_ sender: Any) {
    }
    
    @IBAction func btnCancleAction(_ sender: Any) {
    }
    //sgmntClicklEvent
    
    @IBAction func sgmntGenderAction(_ sender: Any) {
        let sgmntBtn = sender as! UISegmentedControl
        switch sgmntBtn.selectedSegmentIndex {
        case 1:
            print(" Male is selected")
        case 2 :
            print("Female is selected")
        default:
            print("Invalid selecetion")
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
