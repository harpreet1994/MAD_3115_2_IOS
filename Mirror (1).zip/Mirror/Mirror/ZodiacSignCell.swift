//
//  ZodiacSignCell.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-10.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ZodiacSignCell: UICollectionViewCell {
    
    @IBOutlet weak var lblzodiac: UILabel!
    @IBOutlet weak var imgZodiac: UIImageView!
}
