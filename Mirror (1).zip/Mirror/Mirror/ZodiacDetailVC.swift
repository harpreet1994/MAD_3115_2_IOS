//
//  ZodiacDetailVC.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-10.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ZodiacDetailVC: UIViewController {

    @IBOutlet weak var lblZodiac: UILabel!
    @IBOutlet weak var lblZodiacBirthstone: UILabel!
    @IBOutlet weak var lblZodiacColor: UILabel!
    var plistArray = NSMutableArray()
    var selectedZodiac: Int?
    
    override func viewWillAppear(_ animated: Bool) {
        if let index = selectedZodiac{
            self.fetchZodiacDetails()
            self.displayDetails()
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func displayDetails(){
        lblZodiac.text = ZodiacItems.zodiac[self.selectedZodiac!]
        let zodiacdetails = plistArray[self.selectedZodiac!] as! NSMutableDictionary
        self.lblZodiacColor.text = zodiacdetails.value(forKey: "Color") as? String
        self.lblZodiacBirthstone.text = zodiacdetails.value(forKey: "BirthStone") as? String
        
    }
    
    func fetchZodiacDetails(){
        if let filePath = Bundle.main.path(forResource: "Zodiac", ofType: "plist") {
            
            //get an array representation of plist
            plistArray = NSMutableArray(contentsOfFile: filePath)!
            
            print("plistArray \(plistArray)")
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
