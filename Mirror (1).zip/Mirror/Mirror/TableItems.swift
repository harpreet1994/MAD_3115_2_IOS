//
//  TableItems.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class TableItems{
    static var titles : [String] = ["Audio", "Video", "Web View", "Calender", "Location", "Contacts", "Plist"]
    static var subTitles : [String] = ["Hear it clear", "Watch it better", "World is yours", "Time is not yours", "Be everywhere", "Stay Connected", "Your attributes"]
    static var images : [String] = ["Audio", "Video", "Web", "Calender", "Location", "Contacts", "Plist"]
}
