//
//  DateCollectionViewCell.swift
//  Calender
//
//  Created by MacStudent on 2018-08-18.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
class DateCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var lblDate: UILabel!
    
    
    
    
}
