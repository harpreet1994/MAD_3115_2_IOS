//
//  CalendarVars.swift
//  Calender
//
//  Created by MacStudent on 2018-08-18.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
let date = Date()
let calendar = Calendar.current

let day = calendar.component(.day,from:date)
let weekday = calendar.component(.month, from: date)
var year = calendar.component(.year, from: date)
var month = calendar.component(.month, from: date) - 1
