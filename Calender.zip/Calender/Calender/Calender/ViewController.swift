//
//  ViewController.swift
//  Calender
//
//  Created by MacStudent on 2018-08-18.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UICollectionViewDelegate,UICollectionViewDataSource {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        currentMonth = Months[month]
        lblMonth.text = "\(currentMonth)\(year)"
        
    }
    
   
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch Direction{
        case 0:
            return DayInMonths[month] + NumberOfEmptybox
        case 1...:
            return DayInMonths[month] + NumberOfEmptybox
        case -1:
            return DayInMonths[month] + NumberOfEmptybox
            
        default:
            fatalError()
        }

    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:  "Calendar", for: indexPath) as! DateCollectionViewCell
        cell.backgroundColor = UIColor.clear
        
        cell.lblDate.text = UIColor.black
        if cell.isHidden{
            cell.isHidden = false
        }
        
        
        
        switch Direction {
        case 0:
            cell.lblDate.text = "\(indexPath.row + 1 - NumberOfEmptybox)"
            case 1:
                cell.lblDate.text = "\(indexPath.row + 1 - NextNumberOfEmptyBox)"
        case -1:
            cell.lblDate.text = "\(indexPath.row + 1 - previousNumberOfEmptyBox)"
        default:
            fatalError()
        }
        if Int(cell.lblDate.text!)! < 1{
            cell.isHidden = true
        }
        switch indexPath.row {
        case 5,6,12,13,20,26,27,33,34:
            if Int(cell.lblDate.text!)! > 0 {
                cell.lblDate.textColor = UIColor.lightGray
            }
        default:
            break
        }
        if currentMonth == Months[calendar.component(.month, from : date) - 1] && year == calendar.component.year, from: date) && indexPath.row + 1 == day{
        }

    
    
    @IBOutlet weak var calendar: UICollectionView!
    @IBOutlet weak var lblMonth: UILabel!
    
    
   let Months = ["janaury", "february", "MArch", "April", "MAy", "June", "July", "August","September", "October", "November", "December"]
    
    let DayOfMonth = ["Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday", "Sunday"]
    let DayInMonths = [31,28,31,30,31,30,31,31,30,31,30,31]
    var currentMonth = String()
    var NumberOfEmptybox =  Int()
    var NextNumberOfEmptyBox = Int()
    var previousNumberOfEmptyBox = 0
    var Direction = 0
    var positionIndex = 0
    
    
    @IBAction func btnNext(_ sender: Any) {
        switch currentMonth{
        case "december" :
            month = 0
            year += 1
            Direction = 1
            GetStartDAteDayPosition()
            
            currentMonth = Months[month]
              lblMonth.text = "\(currentMonth)\(year)"
            calendar.reloadData()
        default:
           
            Direction = 1
            
            GetStartDAteDayPosition()
              month += 1
            lblMonth.text = "\(currentMonth)\(year)"
            calendar.reloadData()
            
            
        }
        
    }
    
    @IBAction func btnBack(_ sender: Any) {
        switch currentMonth{
        case "January":
            month = 11
            year -= 1
            Direction = -1
            GetStartDAteDayPosition()
            
            
            currentMonth = Months[month]
            lblMonth.text = "\(currentMonth) \(year)"
            calendar.reloadData()
        default:
            month -= 1
            Direction = -1
            GetStartDAteDayPosition()
            
            lblMonth.text = "\(currentMonth)\(year)"
            calendar.reloadData()
            
        }
    }
    func GetStartDAteDayPosition(){
        switch Direction{
        case 0:
            switch day{
            case 1...7:
                NumberOfEmptybox = weekday - day
            case 8...14:
                  NumberOfEmptybox = weekday - day - 7
            case 15...21:
                  NumberOfEmptybox = weekday - day - 14
            case 22...28:
                  NumberOfEmptybox = weekday - day - 21
            case 29...31:
              NumberOfEmptybox = weekday - day - 28
            default:
                break
            }
        
        positionIndex = NumberOfEmptybox
        case 1...:
        NextNumberOfEmptyBox = (positionIndex + DayInMonths[month])%7
            positionIndex = NextNumberOfEmptyBox
        case -1:
            previousNumberOfEmptyBox = (7 - (DayInMonths[month] - positionIndex)%7)
            if previousNumberOfEmptyBox == 7{
                previousNumberOfEmptyBox = 0
            }
            positionIndex = previousNumberOfEmptyBox
        default:
            fatalError()
            
            }
      
   
    


}

}
