//
//  evenOddcellCollectionViewCell.swift
//  EVENODD
//
//  Created by MacStudent on 2018-08-14.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class evenOddcellCollectionViewCell: UICollectionViewCell {
    
}
