//
//  ViewController.swift
//  EVENODD
//
//  Created by MacStudent on 2018-08-14.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
  @IBOutlet weak var lblNumber: UILabel!
    
    
    @IBOutlet weak var lblStatement: UILabel!
    var Number = [10,30,45, 78,40,22,13]
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnRandomnumberAction(_ sender: UIButton) {
        
        
     let randomNumber = Int(arc4random_uniform(50)+1)
         lblNumber.text = "\(randomNumber)"
        for Num : Int in Number{
            if Num % 2 == 0{
                print("\(Num) Even")
                
            }else{
                print("\(Num) Odd")
            }
        }
     
        
       
            
            
            
            
      
    }
    
    


}

